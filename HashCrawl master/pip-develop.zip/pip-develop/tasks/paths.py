import os.path

PROJECT_ROOT = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

CONTRIB = os.path.join(PROJECT_ROOT, "contrib")
